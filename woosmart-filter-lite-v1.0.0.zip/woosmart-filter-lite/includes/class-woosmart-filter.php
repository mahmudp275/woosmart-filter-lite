<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class WSFL_Filter {
    public static function init() {
        add_shortcode( 'woosmart_filter', array( __CLASS__, 'shortcode' ) );
        add_action( 'wp_ajax_wsfl_filter', array( __CLASS__, 'ajax' ) );
        add_action( 'wp_ajax_nopriv_wsfl_filter', array( __CLASS__, 'ajax' ) );
    }
    public static function shortcode( $atts = array() ) {
        $atts = shortcode_atts( array( 'columns' => 3, 'per_page' => 9 ), $atts, 'woosmart_filter' );
        $columns = max( 1, min( 5, absint( $atts['columns'] ) ) );
        $per_page = max( 1, min( 24, absint( $atts['per_page'] ) ) );
        wp_enqueue_style( 'wsfl-style', WSFL_URL . 'assets/css/filter.css', array(), WSFL_VER );
        wp_enqueue_script( 'wsfl-script', WSFL_URL . 'assets/js/filter.js', array(), WSFL_VER, true );
        wp_localize_script( 'wsfl-script', 'WSFLData', array( 'url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'wsfl_filter' ), 'error' => __( 'Could not load products. Please try again.', 'woosmart-filter-lite' ) ) );
        $id = wp_unique_id( 'wsfl-' );
        $categories = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true ) );
        $attributes = wc_get_attribute_taxonomies();
        ob_start(); ?>
        <div class="wsfl" id="<?php echo esc_attr( $id ); ?>" data-columns="<?php echo esc_attr( $columns ); ?>" data-per-page="<?php echo esc_attr( $per_page ); ?>">
            <form class="wsfl-form" aria-label="<?php esc_attr_e( 'Product filters', 'woosmart-filter-lite' ); ?>">
                <h3><?php esc_html_e( 'Filter products', 'woosmart-filter-lite' ); ?></h3>
                <label><?php esc_html_e( 'Search', 'woosmart-filter-lite' ); ?><input name="search" type="search" placeholder="<?php esc_attr_e( 'Search products...', 'woosmart-filter-lite' ); ?>"></label>
                <label><?php esc_html_e( 'Category', 'woosmart-filter-lite' ); ?><select name="category"><option value=""><?php esc_html_e( 'All categories', 'woosmart-filter-lite' ); ?></option><?php if ( ! is_wp_error( $categories ) ) : foreach ( $categories as $term ) : ?><option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option><?php endforeach; endif; ?></select></label>
                <fieldset><legend><?php esc_html_e( 'Price range', 'woosmart-filter-lite' ); ?></legend><div class="wsfl-price"><label><?php esc_html_e( 'Min', 'woosmart-filter-lite' ); ?><input type="number" name="min_price" min="0" step="0.01" placeholder="0"></label><label><?php esc_html_e( 'Max', 'woosmart-filter-lite' ); ?><input type="number" name="max_price" min="0" step="0.01" placeholder="Any"></label></div></fieldset>
                <?php foreach ( (array) $attributes as $attribute ) : $taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name ); if ( ! taxonomy_exists( $taxonomy ) ) { continue; } $terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => true ) ); if ( is_wp_error( $terms ) || ! $terms ) { continue; } ?>
                    <label><?php echo esc_html( $attribute->attribute_label ); ?><select name="attribute[<?php echo esc_attr( $taxonomy ); ?>]"><option value=""><?php esc_html_e( 'Any', 'woosmart-filter-lite' ); ?></option><?php foreach ( $terms as $term ) : ?><option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></label>
                <?php endforeach; ?>
                <label class="wsfl-check"><input type="checkbox" name="in_stock" value="1"> <?php esc_html_e( 'In stock only', 'woosmart-filter-lite' ); ?></label>
                <label class="wsfl-check"><input type="checkbox" name="on_sale" value="1"> <?php esc_html_e( 'On sale only', 'woosmart-filter-lite' ); ?></label>
                <button type="reset" class="wsfl-reset"><?php esc_html_e( 'Reset filters', 'woosmart-filter-lite' ); ?></button>
            </form>
            <div class="wsfl-main"><div class="wsfl-toolbar"><span class="wsfl-count" aria-live="polite"></span><label><?php esc_html_e( 'Sort', 'woosmart-filter-lite' ); ?> <select class="wsfl-sort"><option value="date"><?php esc_html_e( 'Newest', 'woosmart-filter-lite' ); ?></option><option value="price_asc"><?php esc_html_e( 'Price: low to high', 'woosmart-filter-lite' ); ?></option><option value="price_desc"><?php esc_html_e( 'Price: high to low', 'woosmart-filter-lite' ); ?></option><option value="name"><?php esc_html_e( 'Name', 'woosmart-filter-lite' ); ?></option><option value="popular"><?php esc_html_e( 'Popularity', 'woosmart-filter-lite' ); ?></option></select></label></div><div class="wsfl-results" aria-live="polite"><?php echo self::products( array(), $columns, $per_page, 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="wsfl-pagination"></div></div>
        </div>
        <?php return ob_get_clean();
    }
    private static function sanitize_filters( $raw ) {
        $filters = array();
        foreach ( array( 'search', 'category', 'sort' ) as $key ) { $filters[ $key ] = sanitize_text_field( wp_unslash( $raw[ $key ] ?? '' ) ); }
        foreach ( array( 'min_price', 'max_price' ) as $key ) { $v = $raw[ $key ] ?? ''; $filters[ $key ] = ( is_scalar( $v ) && '' !== (string) $v && is_numeric( $v ) ) ? max( 0, (float) $v ) : ''; }
        $filters['in_stock'] = ! empty( $raw['in_stock'] );
        $filters['on_sale'] = ! empty( $raw['on_sale'] );
        $filters['attribute'] = array();
        if ( isset( $raw['attribute'] ) && is_array( $raw['attribute'] ) ) {
            foreach ( wp_unslash( $raw['attribute'] ) as $tax => $slug ) {
                $tax = sanitize_key( $tax );
                if ( taxonomy_exists( $tax ) && 0 === strpos( $tax, 'pa_' ) && is_scalar( $slug ) && '' !== $slug ) { $filters['attribute'][ $tax ] = sanitize_title( $slug ); }
            }
        }
        return $filters;
    }
    public static function products( $raw, $columns, $per_page, $page ) {
        $filters = self::sanitize_filters( $raw );
        $args = array( 'status' => 'publish', 'limit' => $per_page, 'page' => $page, 'paginate' => true, 'return' => 'objects', 'orderby' => 'date', 'order' => 'DESC' );
        if ( $filters['search'] ) { $args['s'] = $filters['search']; }
        if ( $filters['category'] ) { $args['category'] = array( $filters['category'] ); }
        if ( $filters['in_stock'] ) { $args['stock_status'] = 'instock'; }
        if ( $filters['on_sale'] ) { $args['include'] = wc_get_product_ids_on_sale(); if ( ! $args['include'] ) { return '<p class="wsfl-empty">' . esc_html__( 'No products found.', 'woosmart-filter-lite' ) . '</p>'; } }
        if ( '' !== $filters['min_price'] ) { $args['min_price'] = $filters['min_price']; }
        if ( '' !== $filters['max_price'] ) { $args['max_price'] = $filters['max_price']; }
        if ( $filters['attribute'] ) {
            $args['tax_query'] = array( 'relation' => 'AND' );
            foreach ( $filters['attribute'] as $taxonomy => $slug ) { $args['tax_query'][] = array( 'taxonomy' => $taxonomy, 'field' => 'slug', 'terms' => array( $slug ) ); }
        }
        switch ( $filters['sort'] ) {
            case 'price_asc': $args['orderby'] = 'meta_value_num'; $args['meta_key'] = '_price'; $args['order'] = 'ASC'; break;
            case 'price_desc': $args['orderby'] = 'meta_value_num'; $args['meta_key'] = '_price'; $args['order'] = 'DESC'; break;
            case 'name': $args['orderby'] = 'name'; $args['order'] = 'ASC'; break;
            case 'popular': $args['orderby'] = 'popularity'; break;
        }
        $result = wc_get_products( $args );
        $products = is_object( $result ) ? $result->products : array();
        $total = is_object( $result ) ? (int) $result->total : 0;
        $max_pages = is_object( $result ) ? (int) $result->max_num_pages : 0;
        ob_start();
        if ( ! $products ) { echo '<p class="wsfl-empty">' . esc_html__( 'No products found. Try another filter.', 'woosmart-filter-lite' ) . '</p>'; }
        else { echo '<div class="wsfl-grid" style="--wsfl-cols:' . esc_attr( $columns ) . '">'; foreach ( $products as $product ) {
            if ( ! is_a( $product, 'WC_Product' ) ) { continue; }
            echo '<article class="wsfl-card"><a href="' . esc_url( get_permalink( $product->get_id() ) ) . '">';
            echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) );
            echo '<h3>' . esc_html( $product->get_name() ) . '</h3></a><div class="wsfl-card-price">' . wp_kses_post( $product->get_price_html() ) . '</div>';
            echo '<a class="wsfl-view" href="' . esc_url( get_permalink( $product->get_id() ) ) . '">' . esc_html__( 'View product', 'woosmart-filter-lite' ) . '</a></article>';
        } echo '</div>'; }
        echo '<span class="wsfl-meta" hidden data-total="' . esc_attr( $total ) . '" data-pages="' . esc_attr( $max_pages ) . '" data-page="' . esc_attr( $page ) . '"></span>';
        return ob_get_clean();
    }
    public static function ajax() {
        check_ajax_referer( 'wsfl_filter', 'nonce' );
        $filters = isset( $_POST['filters'] ) && is_array( $_POST['filters'] ) ? $_POST['filters'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $page = max( 1, absint( $_POST['page'] ?? 1 ) );
        $per_page = max( 1, min( 24, absint( $_POST['per_page'] ?? 9 ) ) );
        $columns = max( 1, min( 5, absint( $_POST['columns'] ?? 3 ) ) );
        wp_send_json_success( array( 'html' => self::products( $filters, $columns, $per_page, $page ) ) );
    }
}
