<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class WSFL_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'woosmart_filter'; }
    public function get_title() { return __( 'WooSmart Product Filter', 'woosmart-filter-lite' ); }
    public function get_icon() { return 'eicon-filter'; }
    public function get_categories() { return array( 'general' ); }
    protected function register_controls() {
        $this->start_controls_section( 'wsfl_settings', array( 'label' => __( 'Product filter settings', 'woosmart-filter-lite' ) ) );
        $this->add_control( 'columns', array( 'label' => __( 'Columns', 'woosmart-filter-lite' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 5 ) );
        $this->add_control( 'per_page', array( 'label' => __( 'Products per page', 'woosmart-filter-lite' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 9, 'min' => 1, 'max' => 24 ) );
        $this->end_controls_section();
    }
    protected function render() { $s = $this->get_settings_for_display(); echo do_shortcode( '[woosmart_filter columns="' . absint( $s['columns'] ) . '" per_page="' . absint( $s['per_page'] ) . '"]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped }
}
}
