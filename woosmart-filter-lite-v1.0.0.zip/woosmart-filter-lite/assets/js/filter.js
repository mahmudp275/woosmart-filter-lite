(function () {
  'use strict';
  document.querySelectorAll('.wsfl').forEach(function (root) {
    const form = root.querySelector('.wsfl-form');
    const results = root.querySelector('.wsfl-results');
    const counter = root.querySelector('.wsfl-count');
    const pagination = root.querySelector('.wsfl-pagination');
    const sort = root.querySelector('.wsfl-sort');
    let request = null;
    let timer = null;
    function updateUI() {
      const meta = results.querySelector('.wsfl-meta');
      if (!meta) { counter.textContent = ''; pagination.replaceChildren(); return; }
      const total = Number(meta.dataset.total);
      const pages = Number(meta.dataset.pages);
      const page = Number(meta.dataset.page);
      counter.textContent = total + ' product' + (total === 1 ? '' : 's') + ' found';
      pagination.replaceChildren();
      if (pages <= 1) return;
      for (let p = 1; p <= pages; p++) {
        if (pages > 9 && p > 2 && p < pages - 1 && Math.abs(p - page) > 1) continue;
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = String(p);
        button.disabled = p === page;
        button.setAttribute('aria-label', 'Page ' + p);
        if (p === page) button.setAttribute('aria-current', 'page');
        button.addEventListener('click', function () { fetchProducts(p); });
        pagination.appendChild(button);
      }
    }
    function fetchProducts(page) {
      if (request) request.abort();
      request = new AbortController();
      const params = new URLSearchParams();
      params.set('action', 'wsfl_filter');
      params.set('nonce', WSFLData.nonce);
      params.set('page', page);
      params.set('columns', root.dataset.columns);
      params.set('per_page', root.dataset.perPage);
      params.set('filters[sort]', sort.value);
      new FormData(form).forEach(function (value, key) { params.append(key.startsWith('attribute[') ? 'filters[attribute][' + key.slice(10, -1) + ']' : 'filters[' + key + ']', value); });
      results.classList.add('wsfl-loading');
      fetch(WSFLData.url, {method: 'POST', body: params, credentials: 'same-origin', signal: request.signal})
        .then(function (r) { if (!r.ok) throw Error('HTTP error'); return r.json(); })
        .then(function (data) { if (!data.success) throw Error('Request failed'); results.innerHTML = data.data.html; updateUI(); })
        .catch(function (error) { if (error.name !== 'AbortError') { counter.textContent = WSFLData.error; } })
        .finally(function () { results.classList.remove('wsfl-loading'); });
    }
    function queue() { clearTimeout(timer); timer = setTimeout(function () { fetchProducts(1); }, 300); }
    form.addEventListener('input', queue);
    form.addEventListener('change', queue);
    form.addEventListener('reset', function () { setTimeout(function () { fetchProducts(1); }, 0); });
    sort.addEventListener('change', function () { fetchProducts(1); });
    updateUI();
  });
})();
